# Confirm L-K Earn NG — Real Backend Starter

This is a production-oriented backend starter, not a completed live financial service.

Implemented:
- Firestore wallet ledger pattern
- Withdrawal request flow
- Paystack NGN transfer integration skeleton
- Paystack webhook reconciliation
- AdMob rewarded-ad SSV endpoint placeholder
- Environment-based secrets
- Minimum withdrawal configuration

Before live use:
1. Create and verify your own Paystack business account and obtain live keys.
2. Create your own AdMob app/ad units and configure rewarded SSV.
3. Complete the AdMob SSV signature verification code before awarding real points.
4. Add Firebase Authentication and server authorization/custom claims.
5. Add rate limiting, device/account fraud controls, idempotency, audit logs and monitoring.
6. Complete privacy policy, terms, age/eligibility, consumer-protection and tax/regulatory review applicable to your operation.
7. Fund the payout account and test in Paystack's test environment before live payouts.

Never put PAYSTACK_SECRET_KEY in the Android app.
