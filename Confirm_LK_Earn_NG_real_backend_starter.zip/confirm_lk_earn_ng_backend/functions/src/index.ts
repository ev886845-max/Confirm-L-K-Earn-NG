import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import crypto from "crypto";
import admin from "firebase-admin";

dotenv.config();
if (!admin.apps.length) admin.initializeApp();
const db = admin.firestore();

const app = express();
app.use(cors());
app.use(express.json());

const POINTS_PER_NAIRA = Number(process.env.POINTS_PER_NAIRA || 100);
const MIN_WITHDRAW_NAIRA = Number(process.env.MIN_WITHDRAW_NAIRA || 1000);

function requireEnv(name: string) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing environment variable: ${name}`);
  return v;
}

app.get("/health", (_req, res) => res.json({ok:true, service:"Confirm L-K Earn NG API"}));

app.post("/wallet/credit", async (req, res) => {
  // Internal/admin/provider use only. In production protect this route with
  // Firebase Auth + custom claims and idempotency checks.
  const {uid, points, reason, reference} = req.body;
  if (!uid || !Number.isInteger(points) || points <= 0 || !reason || !reference)
    return res.status(400).json({error:"uid, positive integer points, reason and reference are required"});

  const ref = db.collection("users").doc(uid);
  const ledger = db.collection("ledger").doc(reference);
  await db.runTransaction(async t => {
    const [u, l] = await Promise.all([t.get(ref), t.get(ledger)]);
    if (l.exists) throw new Error("duplicate_reference");
    const balance = (u.exists ? (u.data()?.points || 0) : 0) + points;
    t.set(ref, {points: balance, updatedAt: admin.firestore.FieldValue.serverTimestamp()}, {merge:true});
    t.set(ledger, {uid, points, reason, type:"credit", createdAt: admin.firestore.FieldValue.serverTimestamp()});
  });
  res.json({ok:true});
});

// AdMob SSV endpoint. Configure this exact URL in the rewarded ad unit.
// Production must verify the SSV signature before crediting the ledger.
// Google documents SSV as protection against spoofed client-side rewards.
app.get("/admob/ssv", async (req, res) => {
  const {custom_data, transaction_id, reward_amount, reward_item, signature, key_id} = req.query;
  if (!custom_data || !transaction_id || !reward_amount || !signature || !key_id)
    return res.status(400).send("missing");
  // TODO production: verify signature using Google's rotating public keys,
  // reject reused transaction_id, decode custom_data, then credit ledger.
  console.log("AdMob SSV received", {custom_data, transaction_id, reward_amount, reward_item, key_id});
  res.status(200).send("ok");
});

app.post("/withdrawals", async (req, res) => {
  const {uid, amountNaira, bankCode, accountNumber, accountName} = req.body;
  if (!uid || !Number.isFinite(amountNaira) || amountNaira < MIN_WITHDRAW_NAIRA ||
      !bankCode || !accountNumber || !accountName)
    return res.status(400).json({error:`Minimum withdrawal is ₦${MIN_WITHDRAW_NAIRA} and bank details are required`});

  const points = Math.round(amountNaira * POINTS_PER_NAIRA);
  const userRef = db.collection("users").doc(uid);
  const withdrawalRef = db.collection("withdrawals").doc();
  await db.runTransaction(async t => {
    const snap = await t.get(userRef);
    const balance = snap.exists ? (snap.data()?.points || 0) : 0;
    if (balance < points) throw new Error("insufficient_points");
    t.update(userRef, {points: balance - points, updatedAt: admin.firestore.FieldValue.serverTimestamp()});
    t.set(withdrawalRef, {
      uid, amountNaira, points, bankCode, accountNumber, accountName,
      status:"pending", createdAt:admin.firestore.FieldValue.serverTimestamp()
    });
  });
  res.json({ok:true, withdrawalId:withdrawalRef.id, status:"pending"});
});

// Admin payout worker. Keep PAYSTACK_SECRET_KEY server-side only.
// For real production use: create recipient -> initiate transfer -> process
// webhook/status updates -> reconcile ledger.
app.post("/admin/withdrawals/:id/pay", async (req, res) => {
  const id = req.params.id;
  const snap = await db.collection("withdrawals").doc(id).get();
  if (!snap.exists) return res.status(404).json({error:"not_found"});
  const w = snap.data()!;
  if (w.status !== "pending") return res.status(409).json({error:"not_pending"});

  const secret = requireEnv("PAYSTACK_SECRET_KEY");
  const response = await fetch("https://api.paystack.co/transferrecipient", {
    method:"POST",
    headers:{"Authorization":`Bearer ${secret}`,"Content-Type":"application/json"},
    body:JSON.stringify({type:"nuban", name:w.accountName, account_number:w.accountNumber, bank_code:w.bankCode, currency:"NGN"})
  });
  const recipient = await response.json() as any;
  if (!response.ok || !recipient.status) return res.status(502).json({error:"recipient_creation_failed", detail:recipient});

  const reference = `clk_${id}_${crypto.randomBytes(4).toString("hex")}`;
  const payout = await fetch("https://api.paystack.co/transfer", {
    method:"POST",
    headers:{"Authorization":`Bearer ${secret}`,"Content-Type":"application/json"},
    body:JSON.stringify({source:"balance", amount:Math.round(w.amountNaira*100), recipient:recipient.data.recipient_code, reference, reason:"Confirm L-K Earn NG withdrawal", currency:"NGN"})
  });
  const result = await payout.json() as any;
  if (!payout.ok || !result.status) return res.status(502).json({error:"transfer_failed", detail:result});

  await db.collection("withdrawals").doc(id).update({
    status:"processing", paystackReference:reference, updatedAt:admin.firestore.FieldValue.serverTimestamp()
  });
  res.json({ok:true, status:"processing", reference});
});

app.post("/webhooks/paystack", async (req, res) => {
  // Verify x-paystack-signature with HMAC SHA512 using your secret.
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return res.status(500).send("not configured");
  const signature = req.headers["x-paystack-signature"] as string | undefined;
  const raw = JSON.stringify(req.body);
  const expected = crypto.createHmac("sha512", secret).update(raw).digest("hex");
  if (!signature || signature !== expected) return res.status(401).send("invalid signature");

  const event = req.body;
  if (event.event === "transfer.success" || event.event === "transfer.failed" || event.event === "transfer.reversed") {
    const reference = event.data?.reference;
    const q = await db.collection("withdrawals").where("paystackReference","==",reference).limit(1).get();
    if (!q.empty) {
      const status = event.event === "transfer.success" ? "paid" :
        event.event === "transfer.reversed" ? "reversed" : "failed";
      await q.docs[0].ref.update({status, providerEvent:event.event, updatedAt:admin.firestore.FieldValue.serverTimestamp()});
    }
  }
  res.sendStatus(200);
});

app.listen(process.env.PORT || 8080, () => console.log("Confirm L-K Earn NG API running"));
